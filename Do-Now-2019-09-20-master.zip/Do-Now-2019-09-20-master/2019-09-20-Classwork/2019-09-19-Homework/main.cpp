// Name: 
// Intro to CS
// Period 1
// Mr. Williams
// 2019-09-20-Classwork

// Assignment:	Format the code below so that it looks neat.
//				Use the "next line" style for curly brackets.

#include <iostream>

int main()
{std::cout	<< "Name: Mr. Williams" << std::endl << "Class Schedule" << std::endl
				<< "Period 1: Intro to CS" <<std::endl
				<<"Period 2: Earth Science" << std::endl<<"Period 3: PE" << std::endl
				<< "Period 4: Global History" <<std::endl
				<< "Period 5: Visual Arts" 
	
	
	<< std::endl
				<< 
	"Period 6: Lunch" 
	<< std::endl
				<< "Period 7: Geometry" << 
	std::endl
				
	<< "Period 8: House" << std::endl
<< "Period 9: Health" 
	<< std::endl
<< "Period 10: Spanish";}